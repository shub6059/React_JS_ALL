#---- 09 Display string n times ----
string = input('Enter message: ')
num = int(input('How many times should it be displayed? '))
for n in range (1, num + 1):
    print(n , string)
