#---- Pattern with nested loop ----
for row in range(10) :
    for col in range (row):
        print(row , end="")
    print("")