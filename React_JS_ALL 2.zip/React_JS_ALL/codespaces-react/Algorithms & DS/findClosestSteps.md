
  // step#1: init closetValue
  l

  // compare the currentNode with the targetValue
  //==> check as long as it is not eqaul to null --> edge case

    //check closestValue === target 
 
    // init variables for TWO differences
    

    // compare the two difference, edge case
    
      // if true, reassign the closestValue 
    
    // to decide which node direction to traverse?
      // we need a smaller number => go Left
      //=> synatx show how to reassign the currentNode to be the childnNode
        // move to the Right
    
    
