 /*
	we have to traverse both arrays given. 
	
	init pointer in first element of sequence arr. 
	
	put another pointer under first element of array 
	
	compare the two pointers, if the first elemnts arent equal to eachother, so move array pointer up
	
	if the two are equal, move both pointers up. 
	
	gotcha = return pointer equal to our sequence's length
	*/