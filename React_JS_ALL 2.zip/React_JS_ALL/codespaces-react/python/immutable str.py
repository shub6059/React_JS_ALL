s= "  abcd   "
print(s.strip())

print("<" + s + ">")

s = s.strip()
print("<" + s + ">")

