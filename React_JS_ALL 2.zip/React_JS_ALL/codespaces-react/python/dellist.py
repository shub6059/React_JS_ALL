a= list(range(11))
print([a])
del a[5:8]
print(a)
del a[0],a[0]
print(a)

