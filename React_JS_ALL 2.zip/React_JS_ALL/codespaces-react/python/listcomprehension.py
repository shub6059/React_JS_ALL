p=[x**2 for x in range(8)]
print(p)
p.append(p)
print(p)
