from math import sqrt
x=sqrt
print(x(16))
