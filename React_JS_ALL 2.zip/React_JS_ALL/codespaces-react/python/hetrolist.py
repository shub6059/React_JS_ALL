collection = [1,4.5,"hello",-90.5,help]
for i in range(len(collection)):
    print((collection[i]))
for i in collection:
    print(i)
