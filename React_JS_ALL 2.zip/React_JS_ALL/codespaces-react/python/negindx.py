def main():
    data = [1,5,89,78,60]
    print(data[-1])
    print(data[-2])
    print(data[-3])
    print(data[-4])
    print(data[-5])
main()    
