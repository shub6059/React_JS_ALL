
# finite loop
done=False
while not done:
    entry= int(input())
    if entry == 999:
        done = True
    else:
        print(entry)
    
