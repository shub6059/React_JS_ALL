name = input("please enter your name:")
print(name.count('g'))
  
