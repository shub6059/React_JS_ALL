def main():
    x = 0.0
    
    while x!=1.0:
        print("x=",x)
        x+=0.1
main()        
    
