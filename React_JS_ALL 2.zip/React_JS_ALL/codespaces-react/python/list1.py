ist = [1,3,5,9]
print(ist)
print(ist[1])
ist[0]=9
ist[3]=10
print(ist)
print([1,8,70][2])

      
