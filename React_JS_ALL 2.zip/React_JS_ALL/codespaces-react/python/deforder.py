def sum_range(n=0,m):
    sum=0
    for value in range(n,m+1):
        sum += value
    print(sum)        
sum_range(0,7)

        
        
