word ="ABCD"
print(word.rjust(10,"*"))
print(word.rjust(3,"*"))
print(word.rjust(15,">"))
print(word.rjust(5))

