entry =0
sum=0
print("enter numbers to sum:")    
while True:    
    entry= int(input())
    if entry <0:
        break
    sum+= entry
    print("sum=",sum)   
    
   
