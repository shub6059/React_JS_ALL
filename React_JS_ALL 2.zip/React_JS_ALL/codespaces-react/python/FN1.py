from math import sqrt
num = float(input("enter number"))
root = sqrt(num)
print("square_root of",num,"=",root)            

            
