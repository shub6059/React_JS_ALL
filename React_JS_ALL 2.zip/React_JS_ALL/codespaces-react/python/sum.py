#module
'''
this is file created at 10:32 16 Aug, 2019 by Gurtej Kaur
this is the program for addition of two number
'''
a=eval(input('please enter 1st number:'))
b=eval(input('please enter 2nd number:'))
c=a+b
print("sum of a and b = ",c)
#this is a program
x=int(input('please enter an integer'))+(y-2)+16)*2

y=2
x=y+2
y+2=x
