class Mytype:
    def __init__(self):
        self.__id = 2
def main():        
    m=Mytype()
    print(m._Mytype__id)
main()    

        
