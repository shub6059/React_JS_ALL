x=2
a=[0,1]
a+=[x]
print(a)

