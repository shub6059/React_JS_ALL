from time import sleep
for count in range (10,-1,-1):
    print(count,end=' ')
    sleep(1)
