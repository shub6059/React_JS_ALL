num1,num2 = eval(input('please enter nuumber1,number2:'))
print(num1,'+',num2,'=',num1+num2)

