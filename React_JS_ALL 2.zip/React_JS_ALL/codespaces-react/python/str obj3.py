s = "abcdefghijklmnoppqrstuvwxyz"     
print(s.__getitem__(0))
print(s.__getitem__(1))
print(s[0])
print(s[1])
print(s[2])
