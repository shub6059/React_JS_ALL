for p in zip([1,2,3,4,5],[10,11,12,13,14]):
        print(p)
        
for (x,y) in zip([1,2,3,4,5],[10,11,12,13,14]):
        print(x+y)
