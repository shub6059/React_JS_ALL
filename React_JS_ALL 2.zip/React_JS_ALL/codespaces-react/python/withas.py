with open("C:\\Users\\Home-PC\\Desktop\\python auto notes\\jatinder.txt",'r') as f:
    for i in f:
        print(f.read)
        
 
# no need for the close function here. ecause of with\as format

    
          
