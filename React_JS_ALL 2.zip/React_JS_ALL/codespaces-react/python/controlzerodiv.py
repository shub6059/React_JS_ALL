print("please enter two numbers to divide")
num1 = int(input("enter the numerator"))
num2 = int(input("enter the denominator"))
if num2!=0:
    print('{0} divided by{1}={2}'.format(num1,num2,num1/num2))
else:
    print('divison by zero is not possible')
           
          
           
           
