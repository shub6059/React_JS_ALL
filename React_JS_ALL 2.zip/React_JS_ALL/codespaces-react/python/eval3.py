print("enter any expression")
print(eval(input()))
