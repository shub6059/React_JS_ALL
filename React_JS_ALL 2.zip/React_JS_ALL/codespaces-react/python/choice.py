from random import choice
for i in range(10):
    print(choice(("one","two","three","four","five","six","seven","eight","nine",
                  "ten")))
    
hellohellohellohellohello