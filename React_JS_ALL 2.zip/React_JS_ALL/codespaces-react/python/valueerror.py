try:
    val=int(input("please enter small positive number"))
    print("you enterd",val)
    [][2]=5
except ValueError:
    print("input not accepted")
