from prime import is_prime
num = int(input("enter an integer"))
if is_prime(num):
    print(num,"is prime")
else:
    print(num,"is not prime")
    
