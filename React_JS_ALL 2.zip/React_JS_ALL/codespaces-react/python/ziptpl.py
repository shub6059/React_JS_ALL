lst1=[1,2,3,4,5,6,7,8]
lst2=['a','b','c','d','e','f','g','h']
for t in zip(lst1,lst2):
	print(t)
