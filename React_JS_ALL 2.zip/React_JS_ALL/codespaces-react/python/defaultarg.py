def countdown(n=10):
    for count in range(n,-1,-1):
        print(count)
countdown()        
countdown(5)
