def main():
    a=[10]*5
    print(a)
    a=[3.4]*5
    print(a)
    a= 3*["ABC"]
    print(a)
    n=3
    a=n*[4,3.6,"abc"]
    print(a)
main()    
