entry = 0
sum = 0
print(" enter number to sum, negative number ends list:")
while entry >= 0:
    entry = int(input('enter the entry'))
    if entry >= 0:
        sum += entry
        print(" sum =", sum)

    
    
