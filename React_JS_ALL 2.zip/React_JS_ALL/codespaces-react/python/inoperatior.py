a = list(range(0,21,2))
for i in range(-1,24):
    if i in a:
        print(i, "is a member of", a)
    if i not in a:
        print( i, "is not a member of", a)
        
           
    
         
