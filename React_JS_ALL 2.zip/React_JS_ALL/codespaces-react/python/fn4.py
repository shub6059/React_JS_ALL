def counts_to_ten():
    for i in range(1,11):
        print(i, end = '')
    print()
print("going to count to ten....")
counts_to_ten()
print("going to count to ten again....")
counts_to_ten()
