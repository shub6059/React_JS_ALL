a= [10,15,20,25,30]
print(".....original function.....")
print("a=", a)


print(".....reversed function....")
obj1=reversed(a)
print("a=",a)
print("obj1=",obj1)

print("...slice....")
obj2= a[:: -1]
print("a=",a)
print("obj2=",obj2)


print("....reverse method...")
obj3=a.reverse()
print("a=",a)
print("obj3=",obj3)



