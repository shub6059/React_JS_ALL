def counts_to_n(n):
    for i in range(1, n+1):
        print(i, end = '')
    print()
for i in range(1,10):
    counts_to_n(i)


