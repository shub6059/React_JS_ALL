f=open('C:\\Users\\Home-PC\\Desktop\\rajkot data\\happy.txt','r') 
for i in f:
    print(f.readlines(),end='')
   
f.close()    
    
