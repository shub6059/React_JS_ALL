def increment(x):
    print("beginining execution of increment,x=",x)
    x+=1
    print("ending execution of increment,x=",x)
def main():
    x=5
    print("before increment,x=",x)
    increment(x)
    print("after increment,x=",x)
main()

    
