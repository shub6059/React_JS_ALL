const number = [1, 2, 3, 4, 5];
const name = ["anna", "joe", "barry"];
module.exports = { number, name };